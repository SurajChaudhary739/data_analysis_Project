import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Paths (assumes the script is run from the project root)
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
data_path = os.path.join(project_root, "data", "sales_data_raw.csv")
outputs_dir = os.path.join(project_root, "outputs")
os.makedirs(outputs_dir, exist_ok=True)

# Load
df = pd.read_csv(data_path, parse_dates=["date"])
df["promo"] = df["promo"].astype(bool)
df["revenue"] = df["unit_price"] * df["units_sold"]

# Impute missing unit_price with category median
price_median_by_cat = df.groupby("category")["unit_price"].transform("median")
df["unit_price"] = df["unit_price"].fillna(price_median_by_cat)
df["revenue"] = df["unit_price"] * df["units_sold"]

# Outlier capping using IQR
q1 = df["revenue"].quantile(0.25)
q3 = df["revenue"].quantile(0.75)
iqr = q3 - q1
upper_cap = q3 + 1.5 * iqr
df["revenue_capped"] = np.where(df["revenue"] > upper_cap, upper_cap, df["revenue"])

# Features
df["weekday"] = df["date"].dt.weekday
df["is_weekend"] = df["weekday"] >= 5
df["month"] = df["date"].dt.month
df["year"] = df["date"].dt.year

# Aggregations
daily = df.groupby("date").agg(
    total_revenue=("revenue_capped", "sum"),
    total_units=("units_sold", "sum"),
    promo_share=("promo", "mean"),
).reset_index()

category_rev = df.groupby("category")["revenue_capped"].sum().reset_index(name="total_revenue")
region_rev = df.groupby("region")["revenue_capped"].sum().reset_index(name="total_revenue")

monthly = df.groupby([df["date"].dt.to_period("M")])["revenue_capped"].sum().to_timestamp().reset_index()
monthly.columns = ["month", "total_revenue"]
monthly["mom_growth_pct"] = monthly["total_revenue"].pct_change() * 100

# Save tables
daily.to_csv(os.path.join(outputs_dir, "daily_kpis.csv"), index=False)
category_rev.to_csv(os.path.join(outputs_dir, "category_revenue.csv"), index=False)
region_rev.to_csv(os.path.join(outputs_dir, "region_revenue.csv"), index=False)
monthly.to_csv(os.path.join(outputs_dir, "monthly_kpis.csv"), index=False)

# Charts
def save_plot(fig, name):
    out = os.path.join(outputs_dir, name)
    fig.savefig(out, bbox_inches="tight", dpi=150)
    plt.close(fig)

# Revenue over time
fig1 = plt.figure()
plt.plot(daily["date"], daily["total_revenue"])
plt.title("Total Revenue Over Time")
plt.xlabel("Date")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
save_plot(fig1, "01_revenue_over_time.png")

# Units distribution
fig2 = plt.figure()
plt.hist(df["units_sold"], bins=50)
plt.title("Distribution of Units Sold (Line Items)")
plt.xlabel("Units Sold per Line Item")
plt.ylabel("Frequency")
save_plot(fig2, "02_units_distribution.png")

# Category revenue
fig3 = plt.figure()
plt.bar(category_rev["category"], category_rev["total_revenue"])
plt.title("Total Revenue by Category")
plt.xlabel("Category")
plt.ylabel("Revenue")
plt.xticks(rotation=30)
save_plot(fig3, "03_revenue_by_category.png")

# Region revenue
fig4 = plt.figure()
plt.bar(region_rev["region"], region_rev["total_revenue"])
plt.title("Total Revenue by Region")
plt.xlabel("Region")
plt.ylabel("Revenue")
save_plot(fig4, "04_revenue_by_region.png")

# Promo vs No Promo
promo_vs_no = df.groupby("promo")["revenue_capped"].mean().reset_index(name="avg_revenue")
fig5 = plt.figure()
x = ["No Promo", "Promo"]
y = [float(promo_vs_no.loc[promo_vs_no["promo"] == False, "avg_revenue"].values[0]),
     float(promo_vs_no.loc[promo_vs_no["promo"] == True, "avg_revenue"].values[0])]
plt.bar(x, y)
plt.title("Average Revenue per Line Item: Promo vs No Promo")
plt.xlabel("Promotion Flag")
plt.ylabel("Average Revenue")
save_plot(fig5, "05_promo_vs_nopromo_avg_revenue.png")

# Month-over-month growth
fig6 = plt.figure()
plt.plot(monthly["month"], monthly["mom_growth_pct"])
plt.title("Month-over-Month Revenue Growth (%)")
plt.xlabel("Month")
plt.ylabel("Growth %")
plt.xticks(rotation=45)
save_plot(fig6, "06_mom_growth.png")

# Simple 14-day baseline forecast
last_date = daily["date"].max()
lookback_weeks = 8
cutoff_date = last_date - pd.Timedelta(weeks=lookback_weeks)
recent = daily[daily["date"] > cutoff_date].copy()
recent["weekday"] = recent["date"].dt.weekday
weekday_avg = recent.groupby("weekday")["total_revenue"].mean()

future_dates = pd.date_range(last_date + pd.Timedelta(days=1), periods=14, freq="D")
forecast_values = [weekday_avg.get(d.weekday(), daily["total_revenue"].mean()) for d in future_dates]
forecast = pd.DataFrame({"date": future_dates, "forecast_revenue": forecast_values})
forecast.to_csv(os.path.join(outputs_dir, "forecast_14d.csv"), index=False)

# Plot actual vs forecast
plot_history_days = 60
history = daily[daily["date"] > (last_date - pd.Timedelta(days=plot_history_days))]
fig7 = plt.figure()
plt.plot(history["date"], history["total_revenue"], label="Actual (last 60 days)")
plt.plot(future_dates, forecast_values, label="Forecast (next 14 days)")
plt.title("Revenue: Actual vs. 14-Day Baseline Forecast")
plt.xlabel("Date")
plt.ylabel("Revenue")
plt.xticks(rotation=45)
plt.legend()
save_plot(fig7, "07_actual_vs_forecast.png")
