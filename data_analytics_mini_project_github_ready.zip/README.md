# Retail Sales Analytics — Mini Data Analytics Project

This mini project demonstrates a complete analytics workflow on a **synthetic retail sales dataset**.
It includes **data generation**, **cleaning**, **feature engineering**, **KPI analysis**, **visualizations**, and a simple **14-day baseline forecast**.

## Project Structure
```
data_analytics_mini_project/
├─ data/
│  └─ sales_data_raw.csv
├─ outputs/
│  ├─ sales_data_cleaned.csv
│  ├─ daily_kpis.csv
│  ├─ category_revenue.csv
│  ├─ region_revenue.csv
│  ├─ monthly_kpis.csv
│  ├─ forecast_14d.csv
│  ├─ 01_revenue_over_time.png
│  ├─ 02_units_distribution.png
│  ├─ 03_revenue_by_category.png
│  ├─ 04_revenue_by_region.png
│  ├─ 05_promo_vs_nopromo_avg_revenue.png
│  └─ 07_actual_vs_forecast.png
└─ scripts/
   └─ run_analysis.py
```

## How to Run (Locally)
1. Install Python 3.9+.
2. Install dependencies:
   ```bash
   pip install pandas numpy matplotlib
   ```
3. Run:
   ```bash
   python scripts/run_analysis.py
   ```

## Workflow Overview
1. **Data Generation** — Creates a year of daily transactions for multiple stores, regions, and product categories with realistic seasonality and promotions.
2. **Cleaning** — Fixes types, imputes missing prices (by category median), and caps extreme revenue outliers with IQR.
3. **Feature Engineering** — Adds weekday, weekend flag, month, and year.
4. **KPIs** — Aggregates daily totals, category and region revenue, and computes month-over-month growth.
5. **Visualization** — Matplotlib charts for trends, distributions, and category/region performance.
6. **Forecasting** — Baseline 14-day forecast using average revenue by weekday from the last 8 weeks.

## Notes
- This is a **mini** project designed for learning and demonstration. You can replace `data/sales_data_raw.csv` with your own data that has similar columns and rerun the script.

## Installation
```bash
pip install -r requirements.txt
```

## Example Output
![Revenue Over Time](outputs/01_revenue_over_time.png)
